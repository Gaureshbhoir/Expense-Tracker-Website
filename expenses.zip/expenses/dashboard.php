<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: unauthorized.php");
    exit;
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Expense Tracker Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Font Awesome for Icons -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f5f7fa;
    }
    .sidebar {
      height: 100vh;
      background: #212529;
      color: #fff;
      position: fixed;
      top: 0; left: 0;
      width: 240px;
      padding-top: 20px;
    }
    .sidebar a {
      display: block;
      color: #ddd;
      padding: 12px 20px;
      text-decoration: none;
      transition: 0.3s;
    }
    .sidebar a:hover, .sidebar a.active {
      background: #0d6efd;
      color: #fff;
    }
    .content {
      margin-left: 240px;
      padding: 30px;
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
  <div class="sidebar">
    <h4 class="text-center mb-4"><i class="fa-solid fa-coins"></i> Expense Tracker</h4>
    <a href="dashboard.php" class="active"><i class="fa-solid fa-chart-line me-2"></i> Dashboard</a>
    <a href="index.php"><i class="fa-solid fa-plus me-2"></i> Add Transaction</a>
    <a href="display.php"><i class="fa-solid fa-clock-rotate-left me-2"></i> History</a>
    <a href="settings.php"><i class="fa-solid fa-gear me-2"></i> Settings</a>
  </div>

  <!-- Main Content -->
  <div class="content">
    <h1 class="h3 mb-4">Dashboard</h1>

   <?php
// -------- Database Connection ----------
$host = "localhost";
$user = "root"; // change if needed
$pass = "";
$db   = "expense_tracker";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Category wise sum
$sql1 = "SELECT category, SUM(amount) as total FROM expenses GROUP BY category";
$result1 = $conn->query($sql1);
$dataCategory = [];
while ($row = $result1->fetch_assoc()) {
    $dataCategory[] = $row;
}

// Date wise sum (tx_date from your table)
$sql2 = "SELECT tx_date, SUM(amount) as total FROM expenses GROUP BY tx_date ORDER BY tx_date ASC";
$result2 = $conn->query($sql2);
$dataDate = [];
while ($row = $result2->fetch_assoc()) {
    $dataDate[] = $row;
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Expense Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
            background: #f4f7fa;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .chart-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            grid-gap: 30px;
            max-width: 1200px;
            margin: auto;
        }
        .chart-box {
            background: #fff;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            height: 400px; /* fixed height */
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .chart-box canvas {
            width: 100% !important;
            height: 100% !important;
        }
        .line-chart {
            grid-column: span 2; /* make line chart full width */
            height: 450px;       /* taller for time trend */
        }
    </style>
</head>
<body>
    <h2>Expense Dashboard</h2>

    <div class="chart-container">
        <div class="chart-box">
            <canvas id="pieChart"></canvas>
        </div>
        <div class="chart-box">
            <canvas id="barChart"></canvas>
        </div>
        <div class="chart-box line-chart">
            <canvas id="lineChart"></canvas>
        </div>
    </div>

    <script>
        // Get PHP data into JS
        let dataCategory = <?php echo json_encode($dataCategory); ?>;
        let dataDate = <?php echo json_encode($dataDate); ?>;

        function renderCharts() {
            const categories = dataCategory.map(item => item.category);
            const totalsCat = dataCategory.map(item => item.total);

            const dates = dataDate.map(item => item.tx_date);
            const totalsDate = dataDate.map(item => item.total);

            // Destroy old charts if they exist (for auto update)
            if (window.pieChartObj) window.pieChartObj.destroy();
            if (window.barChartObj) window.barChartObj.destroy();
            if (window.lineChartObj) window.lineChartObj.destroy();

            // PIE CHART
            window.pieChartObj = new Chart(document.getElementById("pieChart"), {
                type: "pie",
                data: {
                    labels: categories,
                    datasets: [{
                        data: totalsCat,
                        backgroundColor: ["#FF6384","#36A2EB","#FFCE56","#4CAF50","#9C27B0","#FF9800"]
                    }]
                },
                options: {
                    plugins: {
                        legend: { position: 'bottom' }
                    }
                }
            });

            // BAR CHART
            window.barChartObj = new Chart(document.getElementById("barChart"), {
                type: "bar",
                data: {
                    labels: categories,
                    datasets: [{
                        label: "Expenses",
                        data: totalsCat,
                        backgroundColor: "#36A2EB"
                    }]
                },
                options: {
                    plugins: {
                        legend: { display: false }
                    }
                }
            });

            // LINE CHART (Date-wise)
            window.lineChartObj = new Chart(document.getElementById("lineChart"), {
                type: "line",
                data: {
                    labels: dates,
                    datasets: [{
                        label: "Expenses Over Time",
                        data: totalsDate,
                        fill: true,
                        borderColor: "#FF6384",
                        backgroundColor: "rgba(255,99,132,0.2)",
                        tension: 0.3
                    }]
                },
                options: {
                    plugins: {
                        legend: { position: 'top' }
                    }
                }
            });
        }

        renderCharts();

        // Auto refresh data every 5 seconds
        async function refreshData() {
            const response = await fetch("dashboard.php"); // reload this file
            const text = await response.text();

            // Extract JSON data for both sets
            const matchCat = text.match(/let dataCategory = (.*?);/s);
            const matchDate = text.match(/let dataDate = (.*?);/s);

            if (matchCat && matchDate) {
                dataCategory = JSON.parse(matchCat[1]);
                dataDate = JSON.parse(matchDate[1]);
                renderCharts();
            }
        }

        setInterval(refreshData, 5000);
    </script>
</body>
</html>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>