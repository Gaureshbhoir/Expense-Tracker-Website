<?php
// generate_report.php
require("fpdf.php"); // adjust path if needed

// --- DB ---
$conn = new mysqli("localhost", "root", "", "expense_tracker");
if ($conn->connect_error) { die("DB error"); }

// get data
$sql = "SELECT id, tx_date, category, description, amount
        FROM expenses ORDER BY tx_date DESC";
$result = $conn->query($sql);

// --- PDF ---
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont("Arial", "B", 16);
$pdf->Cell(0, 10, "Expense Tracker Report", 0, 1, "C");
$pdf->Ln(4);

// header
$pdf->SetFont("Arial", "B", 11);
$pdf->Cell(12, 10, "ID", 1, 0, "C");
$pdf->Cell(32, 10, "Date", 1, 0, "C");
$pdf->Cell(32, 10, "Category", 1, 0, "C");
$pdf->Cell(84, 10, "Description", 1, 0, "C");
$pdf->Cell(30, 10, "Amount", 1, 1, "C");

// rows
$pdf->SetFont("Arial", "", 10);
$total = 0.0;

if ($result && $result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $id   = (string)$row['id'];
    $date = (string)$row['tx_date'];
    $cat  = (string)$row['category'];
    $desc = (string)$row['description'];
    $amt  = (float)$row['amount'];
    // shorten long descriptions so the table stays neat
    if (strlen($desc) > 50) $desc = substr($desc, 0, 47) . '...';

    $pdf->Cell(12, 8, $id,   1, 0, "C");
    $pdf->Cell(32, 8, $date, 1, 0, "C");
    $pdf->Cell(32, 8, $cat,  1, 0, "C");
    $pdf->Cell(84, 8, $desc, 1, 0);
    $pdf->Cell(30, 8, number_format($amt, 2), 1, 1, "R");

    $total += $amt;
  }
}

// total row
$pdf->SetFont("Arial", "B", 11);
$pdf->Cell(160, 10, "Total", 1, 0, "R");
$pdf->Cell(30, 10, number_format($total, 2), 1, 1, "R");

// IMPORTANT: no echo/print before Output()
$pdf->Output("D", "Expense_Report.pdf");