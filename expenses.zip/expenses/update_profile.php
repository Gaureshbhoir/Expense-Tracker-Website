<?php
$conn = new mysqli("localhost", "root", "", "expense_tracker");

$id   = $_POST['id'];
$name = $_POST['name'];
$role = $_POST['role'];

// Handle image upload
$profile_pic = null;
if(isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] == 0){
    $targetDir = "uploads/";
    if(!is_dir($targetDir)) mkdir($targetDir);

    $fileName = time() . "_" . basename($_FILES['profile_pic']['name']);
    $targetFile = $targetDir . $fileName;

    if(move_uploaded_file($_FILES['profile_pic']['tmp_name'], $targetFile)){
        $profile_pic = $fileName;
    }
}

// Update query
if($profile_pic){
    $sql = "UPDATE users SET name='$name', role='$role', profile_pic='$profile_pic' WHERE id=$id";
} else {
    $sql = "UPDATE users SET name='$name', role='$role' WHERE id=$id";
}
$conn->query($sql);

header("Location: settings.php");
exit;
?>