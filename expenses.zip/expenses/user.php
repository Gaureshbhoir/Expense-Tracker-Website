<?php
require 'connect.php'; // include PDO connection

$username = "Bhoir";   // choose username
$password = "1234";    // choose password

$hash = password_hash($password, PASSWORD_DEFAULT);

$sql = "INSERT INTO user (username, password) VALUES (?, ?)";
$stmt = $pdo->prepare($sql);
$stmt->execute([$username, $hash]);

echo "User created successfully!<br>";
echo "Username: $username<br>Password: $password";