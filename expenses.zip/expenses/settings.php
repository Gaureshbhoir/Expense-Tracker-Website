
<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: unauthorized.php");
    exit;
}
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Expense Tracker Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Font Awesome for Icons -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f5f7fa;
    }
    .sidebar {
      height: 100vh;
      background: #212529;
      color: #fff;
      position: fixed;
      top: 0; left: 0;
      width: 240px;
      padding-top: 20px;
    }
    .sidebar a {
      display: block;
      color: #ddd;
      padding: 12px 20px;
      text-decoration: none;
      transition: 0.3s;
    }
    .sidebar a:hover, .sidebar a.active {
      background: #0d6efd;
      color: #fff;
    }
    .content {
      margin-left: 240px;
      padding: 30px;
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
  <div class="sidebar">
    <h4 class="text-center mb-4"><i class="fa-solid fa-coins"></i> Expense Tracker</h4>
    <a href="dashboard.php" class="active"><i class="fa-solid fa-chart-line me-2"></i> Dashboard</a>
    <a href="index.php"><i class="fa-solid fa-plus me-2"></i> Add Transaction</a>
    <a href="display.php"><i class="fa-solid fa-clock-rotate-left me-2"></i> History</a>
    <a href="settings.php"><i class="fa-solid fa-gear me-2"></i> Settings</a>
  </div>

  <!-- Main Content -->
  <div class="content">
    <h1 class="h3 mb-4">Settings</h1>

    <?php
$conn = new mysqli("localhost", "root", "", "expense_tracker");

// Fetch user (assuming only 1 user with id=1)
$user = $conn->query("SELECT * FROM users WHERE id=1")->fetch_assoc();

// If no profile picture in DB → set default
$profile_pic = !empty($user['profile_pic']) ? $user['profile_pic'] : "default.png";
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Settings</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap + Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

  <style>
    body {
      background: #f0f6ff;
      font-family: "Segoe UI", sans-serif;
    }
    .settings-card {
      background: #fff;
      border-radius: 20px;
      padding: 30px;
      box-shadow: 0 6px 15px rgba(0,0,0,0.08);
      text-align: center;
      max-width: 500px;
      margin: auto;
    }
    .profile-pic {
      width: 120px;
      height: 120px;
      border-radius: 50%;
      object-fit: cover;
      border: 4px solid #0d6efd;
    }
    .user-info h4 {
      margin: 10px 0 5px;
      font-weight: 600;
    }
    .user-info p {
      margin: 0;
      color: #666;
    }
  </style>
</head>
<body>

<div class="container py-5">
  <div class="settings-card">
    <img src="uploads/<?php echo $profile_pic; ?>" class="profile-pic mb-3" alt="Profile">
    <div class="user-info">
      <h4><?php echo $user['name']; ?></h4>
      <p><?php echo $user['role']; ?></p>
    </div>

    <div class="d-flex justify-content-center gap-3 mt-4 flex-wrap">
      <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editProfileModal">
        <i class="fa-solid fa-user-pen me-2"></i>Edit Profile
      </button>
      <a href="generate_report.php" class="btn btn-primary">
        <i class="fa-solid fa-file-alt me-2"></i>Generate Report
      </a>
      <a href="logout.php" class="btn btn-danger">
        <i class="fa-solid fa-right-from-bracket me-2"></i>Logout
      </a>
    </div>
  </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editProfileModal">
  <div class="modal-dialog">
    <form class="modal-content" action="update_profile.php" method="POST" enctype="multipart/form-data">
      <div class="modal-header"><h5>Edit Profile</h5></div>
      <div class="modal-body">
        <input type="hidden" name="id" value="1">

        <div class="mb-3">
          <label>Name</label>
          <input type="text" name="name" class="form-control" value="<?php echo $user['name']; ?>">
        </div>

        <div class="mb-3">
          <label>Role</label>
          <input type="text" name="role" class="form-control" value="<?php echo $user['role']; ?>">
        </div>

        <div class="mb-3">
          <label>Profile Picture</label>
          <input type="file" name="profile_pic" class="form-control">
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-success">Save</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>