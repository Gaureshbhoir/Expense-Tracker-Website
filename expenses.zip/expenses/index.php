<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Expense Tracker Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Font Awesome for Icons -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f5f7fa;
    }
    .sidebar {
      height: 100vh;
      background: #212529;
      color: #fff;
      position: fixed;
      top: 0; left: 0;
      width: 240px;
      padding-top: 20px;
    }
    .sidebar a {
      display: block;
      color: #ddd;
      padding: 12px 20px;
      text-decoration: none;
      transition: 0.3s;
    }
    .sidebar a:hover, .sidebar a.active {
      background: #0d6efd;
      color: #fff;
    }
    .content {
      margin-left: 240px;
      padding: 30px;
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
  <div class="sidebar">
    <h4 class="text-center mb-4"><i class="fa-solid fa-coins"></i> Expense Tracker</h4>
    <a href="dashboard.php" class="active"><i class="fa-solid fa-chart-line me-2"></i> Dashboard</a>
    <a href="index.php"><i class="fa-solid fa-plus me-2"></i> Add Transaction</a>
    <a href="display.php"><i class="fa-solid fa-clock-rotate-left me-2"></i> History</a>
    <a href="settings.php"><i class="fa-solid fa-gear me-2"></i> Settings</a>
  </div>

  <!-- Main Content -->
  <div class="content">
    <h1 class="h3 mb-4">Add Transactions</h1>

    <?php
// ---- DB CONNECTION ----
$host = 'localhost';
$db   = 'expense_tracker';
$user = 'root';   // change if needed
$pass = '';       // change if needed
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
  PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
  PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  PDO::ATTR_EMULATE_PREPARES => false,
];
try {
  $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
  die("DB Connection failed: " . $e->getMessage());
}

// ---- FORM HANDLING ----
$success = false;
$errorMsg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $tx_date = $_POST['tx_date'] ?? '';
  $category = trim($_POST['category'] ?? '');
  $description = trim($_POST['description'] ?? '');
  $amount = $_POST['amount'] ?? '';

  $errors = [];
  if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tx_date)) {
    $errors[] = 'Valid date is required.';
  }
  if ($category === '') {
    $errors[] = 'Category is required.';
  }
  if ($amount === '' || !is_numeric($amount) || $amount < 0) {
    $errors[] = 'Amount must be a positive number.';
  }

  if (!$errors) {
    $stmt = $pdo->prepare(
      "INSERT INTO expenses (tx_date, category, description, amount)
       VALUES (:tx_date, :category, :description, :amount)"
    );
    $stmt->execute([
      ':tx_date' => $tx_date,
      ':category' => $category,
      ':description' => $description ?: null,
      ':amount' => number_format((float)$amount, 2, '.', ''),
    ]);
    $success = true;
  } else {
    $errorMsg = implode(' ', $errors);
  }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Expense Tracker - Add Expense</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container py-5">
    <div class="row justify-content-center">
      <div class="col-md-8 col-lg-6">
        <div class="card shadow-sm">
          <div class="card-body">
            <h1 class="h4 mb-4">Add Expense</h1>

            <?php if ($success): ?>
              <div class="alert alert-success">✅ Expense saved successfully!</div>
            <?php endif; ?>

            <?php if ($errorMsg): ?>
              <div class="alert alert-danger"><?= htmlspecialchars($errorMsg) ?></div>
            <?php endif; ?>

            <form action="" method="post" novalidate>
              <div class="mb-3">
                <label for="tx_date" class="form-label">Date</label>
                <input type="date" class="form-control" id="tx_date" name="tx_date" required>
              </div>

              <div class="mb-3">
                <label for="category" class="form-label">Category</label>
                <select class="form-select" id="category" name="category" required>
                  <option value="" selected disabled>Choose...</option>
                  <option>Food</option>
                  <option>Transport</option>
                  <option>Bills</option>
                  <option>Shopping</option>
                  <option>Other</option>
                </select>
              </div>

              <div class="mb-3">
                <label for="description" class="form-label">Description (optional)</label>
                <input type="text" class="form-control" id="description" name="description" maxlength="255" placeholder="e.g., Lunch at cafe">
              </div>

              <div class="mb-3">
                <label for="amount" class="form-label">Amount</label>
                <input type="number" class="form-control" id="amount" name="amount" step="0.01" min="0" placeholder="0.00" required>
              </div>

              <button type="submit" class="btn btn-primary w-100">Save Expense</button>
            </form>
          </div>
        </div>
        <p class="text-center text-muted mt-3 small">Expense Tracker Demo</p>
      </div>
    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>