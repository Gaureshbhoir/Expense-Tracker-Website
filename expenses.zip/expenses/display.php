<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Expense Tracker Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Font Awesome for Icons -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

  <!-- DataTables CSS -->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/dataTables.bootstrap5.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.bootstrap5.min.css">

  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f5f7fa;
    }
    .sidebar {
      height: 100vh;
      background: #212529;
      color: #fff;
      position: fixed;
      top: 0; left: 0;
      width: 240px;
      padding-top: 20px;
    }
    .sidebar a {
      display: block;
      color: #ddd;
      padding: 12px 20px;
      text-decoration: none;
      transition: 0.3s;
    }
    .sidebar a:hover, .sidebar a.active {
      background: #0d6efd;
      color: #fff;
    }
    .content {
      margin-left: 240px;
      padding: 30px;
    }
    tfoot input, tfoot select {
      width: 100%;
      padding: 3px;
      box-sizing: border-box;
    }
  </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <h4 class="text-center mb-4"><i class="fa-solid fa-coins"></i> Expense Tracker</h4>
  <a href="dashboard.php"><i class="fa-solid fa-chart-line me-2"></i> Dashboard</a>
  <a href="index.php"><i class="fa-solid fa-plus me-2"></i> Add Transaction</a>
  <a href="display.php" class="active"><i class="fa-solid fa-clock-rotate-left me-2"></i> History</a>
  <a href="settings.php"><i class="fa-solid fa-gear me-2"></i> Settings</a>
</div>

<!-- Main Content -->
<div class="content">
  <h1 class="h3 mb-4">History of Expenses</h1>

<?php
// ---- DB CONNECTION ----
$host = 'localhost';
$db   = 'expense_tracker';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
  PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
  PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  PDO::ATTR_EMULATE_PREPARES => false,
];
try {
  $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
  die("DB Connection failed: " . $e->getMessage());
}

// ---- DELETE HANDLER ----
if (isset($_GET['delete'])) {
  $id = (int) $_GET['delete'];
  $pdo->prepare("DELETE FROM expenses WHERE id = ?")->execute([$id]);
  header("Location: display.php");
  exit;
}

// ---- EDIT HANDLER ----
if (isset($_POST['update'])) {
  $id = (int) $_POST['id'];
  $tx_date = $_POST['tx_date'];
  $category = $_POST['category'];
  $description = $_POST['description'];
  $amount = $_POST['amount'];

  $stmt = $pdo->prepare("UPDATE expenses SET tx_date=?, category=?, description=?, amount=? WHERE id=?");
  $stmt->execute([$tx_date, $category, $description, $amount, $id]);

  header("Location: display.php");
  exit;
}

// ---- FETCH DATA ----
$stmt = $pdo->query("SELECT * FROM expenses ORDER BY id DESC");
$expenses = $stmt->fetchAll();
?>

<div class="container-fluid">
  <div class="card shadow-sm">
    <div class="card-body">
      <?php if ($expenses): ?>
        <div class="table-responsive">
          <table id="expensesTable" class="table table-striped table-bordered align-middle">
            <thead class="table-dark">
              <tr>
                <th>ID</th>
                <th>Date</th>
                <th>Category</th>
                <th>Description</th>
                <th class="text-end">Amount (₹)</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tfoot>
              <tr>
                <th>ID</th>
                <th>Date</th>
                <th>Category</th>
                <th>Description</th>
                <th>Amount (₹)</th>
                <th></th>
              </tr>
            </tfoot>
            <tbody>
              <?php foreach ($expenses as $exp): ?>
                <tr>
                  <td><?= $exp['id'] ?></td>
                  <td><?= htmlspecialchars($exp['tx_date']) ?></td>
                  <td><?= htmlspecialchars($exp['category']) ?></td>
                  <td><?= htmlspecialchars($exp['description'] ?? '-') ?></td>
                  <td class="text-end"><?= number_format($exp['amount'], 2) ?></td>
                  <td>
                    <!-- Edit button -->
                    <button class="btn btn-sm btn-warning editBtn"
                      data-id="<?= $exp['id'] ?>"
                      data-date="<?= $exp['tx_date'] ?>"
                      data-category="<?= htmlspecialchars($exp['category'], ENT_QUOTES) ?>"
                      data-description="<?= htmlspecialchars($exp['description'], ENT_QUOTES) ?>"
                      data-amount="<?= $exp['amount'] ?>">
                      ✏ Edit
                    </button>
                    <!-- Delete button -->
                    <a href="?delete=<?= $exp['id'] ?>" class="btn btn-sm btn-danger"
                       onclick="return confirm('Delete this expense?')">🗑 Delete</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <p class="text-muted">No expenses found.</p>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <form method="post" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Edit Expense</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="id" id="edit-id">
        <div class="mb-3">
          <label>Date</label>
          <input type="date" class="form-control" name="tx_date" id="edit-date" required>
        </div>
        <div class="mb-3">
          <label>Category</label>
          <input type="text" class="form-control" name="category" id="edit-category" required>
        </div>
        <div class="mb-3">
          <label>Description</label>
          <input type="text" class="form-control" name="description" id="edit-description">
        </div>
        <div class="mb-3">
          <label>Amount</label>
          <input type="number" step="0.01" class="form-control" name="amount" id="edit-amount" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" name="update" class="btn btn-primary">Save Changes</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
      </div>
    </form>
  </div>
</div>

</div>

<!-- JS -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.bootstrap5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>

<script>
$(document).ready(function () {
  // Add filter inputs in the footer
  $('#expensesTable tfoot th').each(function (i) {
    var title = $(this).text();
    if (title && title !== "Actions") {
      if (title === "Category") {
        $(this).html('<select class="form-select form-select-sm"><option value="">All</option></select>');
      } else {
        $(this).html('<input type="text" placeholder="Filter ' + title + '" class="form-control form-control-sm" />');
      }
    }
  });

  // Initialize DataTable
  var table = $('#expensesTable').DataTable({
    order: [[0, "desc"]],
    pageLength: 5,
    dom: 'Bfrtip',
    buttons: [
      { extend: 'pdf', className: 'btn btn-sm btn-danger', text: '📄 Export PDF', exportOptions: { columns: ':visible' } },
      { extend: 'print', className: 'btn btn-sm btn-secondary', text: '🖨 Print', exportOptions: { columns: ':visible' } }
    ]
  });

  // Populate category filter dropdown
  table.columns(2).every(function () {
    var column = this;
    var select = $('select', this.footer());
    column.data().unique().sort().each(function (d) {
      select.append('<option value="' + d + '">' + d + '</option>');
    });

    select.on('change', function () {
      var val = $.fn.dataTable.util.escapeRegex($(this).val());
      column.search(val ? '^' + val + '$' : '', true, false).draw();
    });
  });

  // Apply text input filters
  table.columns().every(function () {
    var that = this;
    $('input', this.footer()).on('keyup change clear', function () {
      if (that.search() !== this.value) {
        that.search(this.value).draw();
      }
    });
  });

  // Populate modal with row data
  $('.editBtn').click(function () {
    $('#edit-id').val($(this).data('id'));
    $('#edit-date').val($(this).data('date'));
    $('#edit-category').val($(this).data('category'));
    $('#edit-description').val($(this).data('description'));
    $('#edit-amount').val($(this).data('amount'));
    $('#editModal').modal('show');
  });
});
</script>

</body>
</html>
