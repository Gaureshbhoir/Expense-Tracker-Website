<?php
// unauthorized.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Unauthorized Access</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: linear-gradient(135deg, #ff6b6b, #f06595);
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
      color: white;
    }
    .container {
      background: rgba(0, 0, 0, 0.6);
      padding: 30px;
      border-radius: 15px;
      text-align: center;
      max-width: 400px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    }
    h1 {
      font-size: 28px;
      margin-bottom: 10px;
    }
    p {
      margin-bottom: 20px;
      font-size: 16px;
    }
    a {
      display: inline-block;
      padding: 10px 20px;
      background: #ffffff;
      color: #ff4757;
      text-decoration: none;
      border-radius: 8px;
      font-weight: bold;
      transition: 0.3s;
    }
    a:hover {
      background: #ff6b6b;
      color: #fff;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>🚫 Unauthorized Access</h1>
    <p>You must be logged in to view this page.</p>
    <a href="login.php">🔑 Go to Login</a>
  </div>
</body>
</html>