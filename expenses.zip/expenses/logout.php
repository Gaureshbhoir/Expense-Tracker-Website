<?php
session_start();
session_unset();  // Remove all session variables
session_destroy(); // Destroy the session

// Redirect to login with message
header("Location: login.php?message=loggedout");
exit;
?>